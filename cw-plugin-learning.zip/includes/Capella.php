<?php

namespace Capella;

class Capella {

    public function __construct() {
        echo 'Capellou!';
    }
    
}

