# cw-plugin-learning
1st plugin using OOP and Composer.

# teste!!